/**
 * @description render elem
 * @author wangfupeng
 */

import { h, VNode, VNodeChildren } from 'snabbdom'
import { IDomEditor, SlateElement } from '@wangeditor/editor'
import { UiExpressionElement } from './custom-types'

function renderUiExpression(elem: SlateElement, children: VNode[] | null, editor: IDomEditor): VNode {

  // 构建 vnode
  const { role = '', selected = '', list = [] } = elem as UiExpressionElement

  const options: VNodeChildren = []
  for (let i = 0; i < list.length; i++) {
    const option = h(
      'option',
      {
        attrs: {
          value: list[i].value,
          selected: list[i].value === selected
        }
      },
      list[i].label
    )
    options.push(option)
  }
  const vselectNode = h(
    'select',
    {
      props: {
        contentEditable: false, // 不可编辑
      },
      style: {
        marginLeft: '3px',
        marginRight: '3px',
        backgroundColor: 'var(--w-e-textarea-slight-bg-color)',
        borderRadius: '3px',
        padding: '0 3px',
      },
    },
    options
  )

  return vselectNode
}

function renderUiPlay(elem: SlateElement, children: VNode[] | null, editor: IDomEditor): VNode {
  // 构建 vnode
  const vselectNode = h(
    'span.ui-play',
    {
      props: {
        contentEditable: false, // 不可编辑
      },
      style: {
        marginLeft: '3px',
        marginRight: '3px',
        backgroundColor: 'var(--w-e-textarea-slight-bg-color)',
        borderRadius: '3px',
        padding: '0 3px',
      },
    },
    'Play'
  )

  return vselectNode
}

const renderUiExpressionElemConf = {
  type: 'uiexpression',
  renderElem: renderUiExpression,
}

const renderUiPlayElemConf = {
  type: 'uiplay',
  renderElem: renderUiPlay,
}

export {
  renderUiExpressionElemConf,
  renderUiPlayElemConf,
}