import { IDomEditor, DomEditor, SlateTransforms, SlateNode } from '@wangeditor/editor'
import { Location } from 'slate'
import { IExtendConfig } from './interface'

function getUiEditorConfig(editor: IDomEditor) {
  const { EXTEND_CONF } = editor.getConfig()
  const { uiEditotConfig } = EXTEND_CONF as IExtendConfig
  return uiEditotConfig
}

const lineMap = new Map<number, string>()

const commkeys = ['旁白:', '旁白：', '黑屏文字:', '黑屏文字：']

function containColon(text:string) {
  return text.indexOf(':') !== -1 || text.indexOf('：') !== -1
}

function withUiEditor<T extends IDomEditor>(editor: T): T {   // TS 语法

  const { insertText, isInline, isVoid, deleteBackward } = editor
  const newEditor = editor

  newEditor.insertText = t => {
    
    const { addExpression, addPlay } = getUiEditorConfig(newEditor)

    if (t === ':' || t === '：') { 
      if (addExpression) addExpression(newEditor)
      if (addPlay) addPlay(newEditor)
    }
    insertText(t)
  }

  newEditor.deleteBackward = (unit) => { 
    const { selection } = editor;
    if (!selection) {
      deleteBackward(unit);
      return
    }

    deleteBackward(unit);

    const line = selection.anchor.path[0]
    if (SlateNode.has(editor, selection.anchor.path)) {
      const node = SlateNode.get(editor, selection.anchor.path);
      if (node) {
        const text = SlateNode.string(node);
        if (text) {
          const isInclude = commkeys.some(commkey => text.includes(commkey))
          if (isInclude) {
            return
          }
          const preText = lineMap.get(line)
          if (preText) {
            if (containColon(preText) && !containColon(text)) {
              SlateTransforms.deselect(editor); // 确保没有选中内容
              removeNode('uiexpression', newEditor)
              removeNode('uiplay', newEditor)
              SlateTransforms.select(editor, selection); // 恢复之前的选区
            }
          }
          lineMap.set(line, text)
        }
      }
    }
  }

 // 重写 isInline
  newEditor.isInline = elem => {
    const type = DomEditor.getNodeType(elem)
    if (type === 'uiexpression' || type === 'uiplay') {
      return true
    }
    return isInline(elem)
  }

  // 重写 isVoid
  newEditor.isVoid = elem => {
    const type = DomEditor.getNodeType(elem)
    if (type === 'uiexpression' || type === 'uiplay') {
      return true
    }
    return isVoid(elem)
  }
  return editor
}

const removeNode = (nodeType: string, editor: IDomEditor) => {
  let removePath: Location = []
  let line = 0
  if (editor && editor.selection) {
    line = editor.selection.anchor.path[0]
  }
  for (const [node, path] of SlateNode.descendants(editor, { from: [line] })) {
      const type = DomEditor.getNodeType(node);
      if (type === nodeType) {
        removePath = path
      }
  }
  if (removePath.length > 0) {
    SlateTransforms.removeNodes(editor, { at: removePath });
  }
}


export default withUiEditor